-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Värd: 127.0.0.1
-- Tid vid skapande: 01 mars 2018 kl 14:42
-- Serverversion: 10.1.21-MariaDB
-- PHP-version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databas: `citrus`
--

-- --------------------------------------------------------

--
-- Tabellstruktur `answers`
--

CREATE TABLE `answers` (
  `murder` varchar(128) NOT NULL,
  `weapon` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `answers`
--

INSERT INTO `answers` (`murder`, `weapon`) VALUES
('female1', 'iron');

-- --------------------------------------------------------

--
-- Tabellstruktur `clues`
--

CREATE TABLE `clues` (
  `id` varchar(2) NOT NULL,
  `header` varchar(128) NOT NULL,
  `imgSrc` varchar(128) NOT NULL,
  `icon` varchar(128) NOT NULL,
  `info` varchar(500) NOT NULL,
  `clue_lat` decimal(8,6) NOT NULL,
  `clue_lng` decimal(8,6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `clues`
--

INSERT INTO `clues` (`id`, `header`, `imgSrc`, `icon`, `info`, `clue_lat`, `clue_lng`) VALUES
('1', 'Ledtråd 1', '../media/img/snow.jpg', '../media/img/pins/red_MarkerC.png', 'Bävvern har blood på tanden', '59.314560', '18.112852'),
('2', 'Ledtråd 2', '../media/img/roof.jpg', '../media/img/pins/green_MarkerD.png', 'Elefanten har blod på snabeln', '59.314910', '18.115277'),
('3', 'Ledtråd 3', '', '../media/img/pins/red_MarkerC.png', 'Mördarens fotspår finns kvar i snön. Det är ett par grova kängor i storlek 45.', '59.313387', '18.116409'),
('4', 'Ledtråd 4', '', '../media/img/pins/red_MarkerC.png', 'Här i backen har ett vittne sett mördaren springa. Mördaren hade ett bananskal under skosulan.', '59.313990', '18.116035'),
('5', 'Ledtråd 5', '', '../media/img/pins/red_MarkerC.png', 'I den gröna containern upphittas ett starkt bevismaterial som tros vara mördarens mordvapen', '59.314433', '18.115338'),
('6', 'Ledtråd 6', '', '../media/img/pins/green_MarkerD.png', 'Efter att ha knackat dörr får vi ett intresant vittnesmål från en man som var ute och rastade hunden, när plötsligt en kraftig typ med huvtröja springer in i honom', '59.313814', '18.115123'),
('7', 'Ledtråd 7', '', '../media/img/pins/blue_MarkerB.png', 'Många spår leder till att mördaren kan bo i detta hus, men efter ett snack med grannen så inser vi att kvinnan är bortrest på semester i Spanien 4 månader.', '59.313672', '18.112505'),
('8', 'Ledtråd 8', '', '../media/img/pins/orange_MarkerE.png', 'Från en övervakningskamera får vi ta del av bilder när mordet sker, det är tyvärr mörkt men vi kan se att mördaren bär en svart huvtröja och har kraftig skäggväxt', '59.313808', '18.111924'),
('9', 'Ledtråd 9', '', '../media/img/pins/green_MarkerD.png', 'En servitris från hotellet har uppmärksammat en märklig typ som kastat något i vattnet. Utredningsteamets dykare har funnit papper som verkar vara  intressanta för utredningen.', '59.314863', '18.109251');

-- --------------------------------------------------------

--
-- Tabellstruktur `groups`
--

CREATE TABLE `groups` (
  `groupName` varchar(255) NOT NULL,
  `groupID` int(11) NOT NULL,
  `group_points` int(128) NOT NULL,
  `group_guesses` int(2) NOT NULL DEFAULT '2',
  `gameover` tinyint(1) NOT NULL,
  `timer_ends_at` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `groups`
--

INSERT INTO `groups` (`groupName`, `groupID`, `group_points`, `group_guesses`, `gameover`, `timer_ends_at`) VALUES
('gruppNamn', 8, 900, 2, 0, ''),
('Citrus', 9, 0, 2, 0, ''),
('tigerbalsam', 10, 500, 2, 0, ''),
('hejhejeje', 11, 700, 2, 1, 'Sep 5, 2018 14:34:39');

-- --------------------------------------------------------

--
-- Tabellstruktur `group_members`
--

CREATE TABLE `group_members` (
  `userName` text NOT NULL,
  `userRank` text CHARACTER SET utf8 COLLATE utf8_swedish_ci NOT NULL,
  `id_uesless` int(255) NOT NULL,
  `groupID` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `group_members`
--

INSERT INTO `group_members` (`userName`, `userRank`, `id_uesless`, `groupID`) VALUES
('Elin', 'Admin', 35, 8),
('mickeP', 'medlem', 36, 8),
('hej1', 'inväntar svar', 37, 8),
('Jkid', 'inväntar svar', 38, 8),
('elinnnn', 'inväntar svar', 39, 8),
('jocke1', 'Admin', 40, 9),
('peter', 'inväntar svar', 41, 11),
('simon123', 'medlem', 42, 11),
('hej11', 'Admin', 43, 11);

-- --------------------------------------------------------

--
-- Tabellstruktur `played_match`
--

CREATE TABLE `played_match` (
  `match_id` int(128) NOT NULL,
  `team_id` int(128) NOT NULL,
  `isActive` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `played_match`
--

INSERT INTO `played_match` (`match_id`, `team_id`, `isActive`) VALUES
(1, 0, 0);

-- --------------------------------------------------------

--
-- Tabellstruktur `team_clues`
--

CREATE TABLE `team_clues` (
  `clue_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `team_clues`
--

INSERT INTO `team_clues` (`clue_id`, `team_id`) VALUES
(7, 11),
(9, 11),
(8, 11),
(8, 11);

-- --------------------------------------------------------

--
-- Tabellstruktur `user`
--

CREATE TABLE `user` (
  `id` int(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `uid` text NOT NULL,
  `pwd` varchar(128) NOT NULL,
  `user_points` int(128) DEFAULT '0',
  `team_id` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `user`
--

INSERT INTO `user` (`id`, `email`, `uid`, `pwd`, `user_points`, `team_id`) VALUES
(1, 'jocke@jocke.se', 'Jkid', '$2y$10$EdC4OvhviC25UR7M/kxy2u21QOEfVLE7bjBkrnziWXmm4NnvJstDi', NULL, ''),
(2, 'mikey@example.se', 'mickeP', '$2y$10$zN7QG2AMo6oWUCbyP6itN.juZsHaD2Wqx0DupNBEpRABTumbyNbzW', NULL, '8'),
(3, 'simon@simon.se', 'simon', '$2y$10$0KxAu.0w7TQzVjVgBu4MLO05pJOKiIh27sFecHSTMIe7.4dzxlFO6', NULL, ''),
(4, 'mickepicke@example.se', 'PerUlrich', '$2y$10$dCOSGe1H.6R2ckUHJlBN2OxaSR39yR8.CAEEoAYcdlx5kPEDxku5.', NULL, ''),
(5, 'ElinKviberg@example.se', 'Elin', '$2y$10$2YfbZejSU.Fc37cL3how.utL1zrpolCOArpDp4kHamWjBpt.rWGAq', NULL, ''),
(6, 'Simon.gribert@student.kyh.se', 'suracitroner', '$2y$10$Qz.AUg9ytm.WREnP.4t9F.ITQijKZxcP7q645d3y2HYFDT2rj04Z.', NULL, ''),
(7, 'hejhej@hotmail.com', 'pelle', '$2y$10$0qEl0CBcsgwYoaVEt.unKOrkCNnToGcqGlRlIUNBFuxTa5y3dn35m', NULL, ''),
(8, 'asd@hotmail.com', 'Elinnn', '$2y$10$3zA/5ggeW8JF1j7C/G5hF.XNSMVrnZ0LF83t3T87fTjdSwpgsTSNS', NULL, ''),
(9, 'example@hotmail.com', 'mickeg', '$2y$10$ERsm.qETzBorZgmGAoFU4uXfpBPpTDNx56mMssoXpm.412dkal8KS', NULL, ''),
(10, 's.b@mail.com', 'xXx_Drag0nF1re_xXx', '$2y$10$3T5nraDqXwTR7cr7g5ZDWef0SKXzh6iwGDAganVG2hcquROXo6ssi', 500, ''),
(11, 'jocke1@jocke.se', 'jocke1', '$2y$10$eXp7bmWp82hq4TAuhNqh8u6Vj2jp9Q9dTRQmAeGzTbQEqIVaDRgLi', NULL, '9'),
(12, 'example@hotmail.com', 'tobbe', '$2y$10$p5v/j6yO9KskKDevSHy63OzNYJ3BKzR1RQlUZ/aB2/XaBn4LCx6dq', 0, ''),
(13, 'newPlayer@example.se', 'sven', '$2y$10$PtTurj5PfIfF0Kwh2kh6tOupXadRVqRnkpvRRDsVxYsXlwz/v.jLa', 0, ''),
(14, 'simon.g@comhem.se', 'simon123', '$2y$10$VVNTg72ChgAV67blh/LQbeoST2IGlTySSVI7I8YnR1L6kbafx/wxq', 1000, '0'),
(16, 'exa@live.se', 'mikael', '$2y$10$ZCEwGRNCYjjt768eYEW0YOtCWZwT2Am377ktk56oK2hcq/jVTEKr2', 500, '10'),
(17, 'asd@hotmail.com', 'hej11', '$2y$10$DIZhIXjplX78Weh6guOXzOMi/RyG7JWQK0IYE/.UwDBj07DXwz3AC', 300, '11'),
(18, 'asd@hotmail.com', 'peter', '$2y$10$vJgyKHuvasM5tqp8TAbuw.oAPgtGC7skGf7smxYlbdqt5qMQzPFO.', 200, '11');

--
-- Index för dumpade tabeller
--

--
-- Index för tabell `clues`
--
ALTER TABLE `clues`
  ADD PRIMARY KEY (`id`);

--
-- Index för tabell `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`groupID`);

--
-- Index för tabell `group_members`
--
ALTER TABLE `group_members`
  ADD PRIMARY KEY (`id_uesless`);

--
-- Index för tabell `played_match`
--
ALTER TABLE `played_match`
  ADD PRIMARY KEY (`match_id`);

--
-- Index för tabell `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT för dumpade tabeller
--

--
-- AUTO_INCREMENT för tabell `groups`
--
ALTER TABLE `groups`
  MODIFY `groupID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT för tabell `group_members`
--
ALTER TABLE `group_members`
  MODIFY `id_uesless` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT för tabell `played_match`
--
ALTER TABLE `played_match`
  MODIFY `match_id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT för tabell `user`
--
ALTER TABLE `user`
  MODIFY `id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
